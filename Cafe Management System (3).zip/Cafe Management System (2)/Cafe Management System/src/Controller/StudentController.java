/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Controller;

import javax.swing.JOptionPane;
import Model.AddRecord;

/**
 *
 * @author Acer
 */
public class StudentController {
    
    public static void Form(String id, String Name , String pass) {
        
        new AddRecord().Form(id, Name, pass);

JOptionPane.showMessageDialog(null, "New Record hasbeen inserted", "Successfull",JOptionPane.INFORMATION_MESSAGE);

}
    
}
