/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.ResultSet;
import java.sql.Statement;

/**
 *
 * @author Acer
 */
public class DBUpdate {
    Statement stmt;
    ResultSet rs;
    
    public ResultSet update(String uid){
    
    
        try {
            
            stmt = MyConnection.getStatementConnection();
            String pw = null;
            String uName = null;
            String userId = null;
            
           stmt.executeUpdate("UPDATE info SET username ='"+uName+"', password ='"+pw+"' WHERE us_id ='"+userId+"'");
            
            
        } catch (Exception e) {
        }
    
    return rs;
    }
}
