/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package Model;

import java.sql.Statement;

/**
 *
 * @author Acer
 */
public class AddRecord {
    
    Statement stmt;
public void Form(String id, String Name, String pass) {
    
    
    try {
        
        stmt = MyConnection.getStatementConnection();

String memid = id;
String memName = Name;
String password = pass;


stmt.executeUpdate("INSERT INTO `user`(`us_id` ,`username`, `password`) VALUES('"+memid+"', '"+memName+"' ,'"+password+"')");

        
        
        
    } catch (Exception e) {
    }
    
    
}
    
}
